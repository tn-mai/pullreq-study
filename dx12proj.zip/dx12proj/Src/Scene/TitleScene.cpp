#include "TitleScene.h"
#include "../Graphics.h"
#include "../GamePad.h"

#include "../PSO.h"

using namespace DirectX;

/**
 * @desc	�^�C�g���V�[���I�u�W�F�N�g���쐬����
 * @return	�쐬�����^�C�g���V�[���I�u�W�F�N�g�ւ̃|�C���^
 */
ScenePtr TitleScene::Create()
{
	 return ScenePtr( new TitleScene ) ;
}

// �R���X�g���N�^
TitleScene::TitleScene() : Scene(L"Title") {}

/**
* �V�[����ǂݍ���.
*/
bool TitleScene::Load()
{
	Graphics& graphics = Graphics::Get();

	TextureLoader loader;
	loader.Begin(graphics.csuDescriptorHeap);
	if (!loader.LoadFromFile(texture[0], 0, L"../Res/Image/UnknownPlanet.png")) {
		return false;
	}
	if (!loader.LoadFromFile(texture[1], 1, L"../Res/Image/Font.png")) {
		return false;
	}
	ID3D12CommandList* ppCommandLists[] = { loader.End() };
	graphics.commandQueue->ExecuteCommandLists(_countof(ppCommandLists), ppCommandLists);
	graphics.WaitForGpu();

	cellList.LoadFromJSONFile(L"../Res/Font.cell");
	seStart = AudioEngine::Get().Prepare(L"../Res/Audio/Start.wav");

	const PSO& pso = GetPSO(PSOType_Sprite);
	ID3D12DescriptorHeap* texDescHeap = graphics.csuDescriptorHeap.Get();
	bundleId[0] = graphics.spriteRenderer.CreateBundle(pso, texDescHeap, texture[0]);
	bundleId[1] = graphics.spriteRenderer.CreateBundle(pso, texDescHeap, texture[1]);

	const XMFLOAT2 center(graphics.viewport.Width*0.5f, graphics.viewport.Height*0.5f);
	spriteList.push_back(Sprite(XMFLOAT3(center.x, center.y, 0.5f)));
	spriteList.back().animeController.SetCellIndex(129);
	spriteList.push_back(Sprite(XMFLOAT3(center.x, center.y * 0.75f, 0.5f)));
	spriteList.back().animeController.SetCellIndex(128);
	const char start[] = "START";
	XMFLOAT3 pos( ( center.x - 40.0f ), ( center.y * 1.5f ), 0.5f );
	XMVECTORF32 color = { 1, 1, 1, 1 };
	const XMVECTORF32 colorFactor = { 0.9f, 0.9f, 0.9f, 1 };
	for (const char c : start) {
		spriteList.push_back(Sprite(pos));
		spriteList.back().animeController.SetCellIndex(c);
		color.v *= colorFactor.v;
		XMStoreFloat4(&spriteList.back().color, color);
		pos.x += 16;
	}

	return true;
}

/**
 * @desc	�V�[���̍X�V
 * @param	delta �O��̌Ăяo������̌o�ߎ���
 * @return	�I���R�[�h
 */
int TitleScene::Update( double delta )
{
	for ( Sprite& sprite : spriteList) {
		sprite.Update(delta);
	}

	if (startTimer > 0) {
		startTimer -= delta;
		if (startTimer <= 0) {
			return ExitCode_Exit;
		}
		const float blink = (std::fmod(startTimer, 0.25) > 0.125) ? 0.0f : 1.0f;
		for (auto itr = spriteList.begin() + 2; itr != spriteList.end(); ++itr) {
			itr->color.w = blink;
		}
	}
	else
	{
		const GamePad gamepad = GetGamePad( GamePadId_1P );
		if (gamepad.buttonDown & (GamePad::A | GamePad::B | GamePad::START)) {
			startTimer = 3;
			seStart->Play();
		}
	}
	return ExitCode_Continue;

}
/**
 * @desc	�V�[���̕`��
 */
void TitleScene::Draw() const
{
	Graphics& graphics = Graphics::Get();

	RenderingInfo renderingInfo;
	renderingInfo.rtvHandle = graphics.GetRTVHandle();
	renderingInfo.dsvHandle = graphics.GetDSVHandle();
	renderingInfo.viewport = graphics.viewport;
	renderingInfo.scissorRect = graphics.scissorRect;
	renderingInfo.texDescHeap = graphics.csuDescriptorHeap.Get();
	renderingInfo.matViewProjection = graphics.matViewProjection;

	const Sprite* p = spriteList.data();
	const size_t end = spriteList.size();
	graphics.spriteRenderer.Draw( ( p + 0 ), ( p + 1 ), cellList.list.data(), bundleId[0], renderingInfo);
	graphics.spriteRenderer.Draw( ( p + 1 ), ( p + end ), cellList.list.data(), bundleId[1], renderingInfo);

}